# Control de Vacunas de Mascotas

Aplicación ASP.NET Core MVC con SQL Server para gestionar mascotas y sus vacunas.

## 🚀 Configuración rápida

1. Clonar el repositorio:
```bash
git clone https://github.com/tuusuario/ControlVacunasMascotas.git
cd ControlVacunasMascotas
```

2. Configurar la cadena de conexión en `appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=VacunasDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

3. Crear la base de datos con Entity Framework:
```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

4. Ejecutar el proyecto:
```bash
dotnet run
```

Abre [http://localhost:5000](http://localhost:5000) en tu navegador.

## 📦 Tecnologías
- ASP.NET Core MVC
- Entity Framework Core
- SQL Server 2019
- Bootstrap
