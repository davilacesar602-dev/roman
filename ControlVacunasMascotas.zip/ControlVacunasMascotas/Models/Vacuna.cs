using System;

namespace ControlVacunasMascotas.Models
{
    public class Vacuna
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaAplicacion { get; set; }
        public DateTime ProximaAplicacion { get; set; }

        public int MascotaId { get; set; }
        public Mascota Mascota { get; set; }
    }
}