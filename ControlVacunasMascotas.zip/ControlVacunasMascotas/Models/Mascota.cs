using System;
using System.Collections.Generic;

namespace ControlVacunasMascotas.Models
{
    public class Mascota
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }  // Ej: perro, gato
        public DateTime FechaNacimiento { get; set; }
        public List<Vacuna> Vacunas { get; set; }
    }
}