using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ControlVacunasMascotas.Models;
using System.Threading.Tasks;
using System.Linq;

namespace ControlVacunasMascotas.Controllers
{
    public class VacunasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VacunasController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var vacunas = _context.Vacunas.Include(v => v.Mascota);
            return View(await vacunas.ToListAsync());
        }

        public IActionResult Create()
        {
            ViewData["Mascotas"] = _context.Mascotas.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Vacuna vacuna)
        {
            if (ModelState.IsValid)
            {
                _context.Add(vacuna);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(vacuna);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var vacuna = await _context.Vacunas.FindAsync(id);
            if (vacuna == null) return NotFound();
            ViewData["Mascotas"] = _context.Mascotas.ToList();
            return View(vacuna);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Vacuna vacuna)
        {
            if (id != vacuna.Id) return NotFound();
            if (ModelState.IsValid)
            {
                _context.Update(vacuna);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(vacuna);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var vacuna = await _context.Vacunas.Include(v => v.Mascota).FirstOrDefaultAsync(v => v.Id == id);
            if (vacuna == null) return NotFound();
            return View(vacuna);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vacuna = await _context.Vacunas.FindAsync(id);
            _context.Vacunas.Remove(vacuna);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}